# Fadjar Fish Farm — Dashboard Stok Ikan

Website React untuk monitoring keep stock, penjualan, data loss, inventory, laporan, dan master data.

## Menjalankan di komputer

Pastikan Node.js versi 20 atau lebih baru sudah terpasang.

```bash
npm install
npm run dev
```

Buka alamat lokal yang ditampilkan Vite.

## Build untuk produksi

```bash
npm run build
npm run preview
```

## Deploy ke GitHub Pages

1. Buat repository baru di GitHub dan unggah seluruh isi folder ini.
2. Buka **Settings → Pages**.
3. Pada **Build and deployment**, pilih **GitHub Actions**.
4. Tambahkan workflow `.github/workflows/deploy.yml` (file ini sudah disertakan).
5. Tunggu workflow selesai, lalu buka URL GitHub Pages yang ditampilkan.

## Penyimpanan data

Data disimpan di `localStorage` browser/perangkat yang digunakan. Data tidak otomatis tersinkron ke perangkat lain dan dapat hilang jika data situs/browser dibersihkan. Ekspor/cadangkan data secara berkala jika tersedia di aplikasi.

## Catatan

- Project memakai Vite + React, Tailwind CSS, Lucide, Recharts, dan XLSX.
- `base: "./"` di konfigurasi Vite membantu aset bekerja di subpath GitHub Pages.
